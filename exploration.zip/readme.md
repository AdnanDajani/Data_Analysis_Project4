# (Dataset Exploration Title)
## by (your name here)


## Dataset
The data is a data of Ford bike rental service in  San Francisco Bay Area in 2019. It shows timing of start to end of the rental trip, start and end startion and which bike is used.
The dataframe has 174952 individual rides.
The data includes
- trip duration: duration of individual trip in seconds
- start and end time of the trip
- start and end stations: their name, id and location
- bike information: their ID
- day of the week of the rental
- age of the member in the time of the study (2019)


## Summary of Findings

I found that weekdays perform much better than weekends in terms of rents, especially Sundays and Saturdays. And males are the main users of the bikes as they use more bikes. But when it comes to the trip duration, females tend to use the bike longer than other in a single bike ride.


## Key Insights for Presentation

I focused my presentation on the comparison of genders in service usage. I checked which gender uses the service more, and how long do genders use the bikes for. Also, checked the duration of the trips in various days of the week.